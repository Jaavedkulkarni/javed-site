export default function Cover({ b, name }) {
  if (b.cover) return <img className="cimg" src={b.cover} alt={b.title} />;
  const base = { प्रेरणा: 200, विचार: 340, कथा: 165, मजेदार: 25 }[b.category] ?? 200;
  return (
    <div className="cover" style={{ '--h': base + (b.id % 7) * 9 }}>
      <div><i />{b.title}</div>
      <small>{name}</small>
    </div>
  );
}
