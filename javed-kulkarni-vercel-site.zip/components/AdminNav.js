import Link from 'next/link';
export default function AdminNav() {
  return (
    <nav className="subnav">
      <Link href="/admin">डॅशबोर्ड</Link><Link href="/admin/books">पुस्तके</Link><Link href="/admin/posts">लेखन</Link>
      <Link href="/admin/reviews">अभिप्राय</Link><Link href="/admin/messages">संदेश</Link><Link href="/admin/readers">वाचक</Link><Link href="/admin/settings">सेटिंग्ज</Link>
    </nav>
  );
}
