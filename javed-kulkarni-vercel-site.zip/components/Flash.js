export default function Flash({ m }) {
  return m ? <div className="wrap"><p className="flash" role="status">{String(m).slice(0, 300)}</p></div> : null;
}
