import Link from 'next/link';
import { one } from '@/lib/db';
import { hashTok } from '@/lib/auth';
import Flash from '@/components/Flash';
export const metadata = { title: 'नवा पासवर्ड' };
export default async function Reset({ searchParams }) {
  const { token = '', m } = await searchParams;
  const tok = String(token);
  const row = /^[a-f0-9]{64}$/.test(tok) ? await one('select 1 as x from resets where token=$1 and expires>$2', [hashTok(tok), Date.now()]).catch(() => null) : null;
  return (
    <>
      <Flash m={m} />
      <div className="wrap page narrow">
        <h1>नवा पासवर्ड</h1>
        {!row ? (
          <p className="flash">ही लिंक चुकीची किंवा कालबाह्य झाली आहे. <Link href="/forgot">नवी लिंक मागवा</Link>.</p>
        ) : (
          <form className="form" method="post" action="/api/reset">
            <input type="hidden" name="token" value={tok} />
            <label>नवा पासवर्ड (किमान ८ अक्षरे)<input type="password" name="password" minLength={8} required /></label>
            <button className="btn" type="submit">पासवर्ड बदला</button>
          </form>
        )}
      </div>
    </>
  );
}
