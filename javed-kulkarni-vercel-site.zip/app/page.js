import Link from 'next/link';
import { redirect } from 'next/navigation';
import { q } from '@/lib/db';
import { getSettings } from '@/lib/settings';
import { CATS, CATINTRO } from '@/lib/util';
import Cover from '@/components/Cover';
import Flash from '@/components/Flash';

export default async function Home({ searchParams }) {
  const { m } = await searchParams;
  const s = await getSettings();
  let books = null;
  try { books = await q('select * from books order by sort,id'); } catch {}
  if (!books || !s.site_name) redirect('/setup');
  const feat = books.find((b) => b.featured) || books[0];
  const name = s.site_name;
  return (
    <>
      <Flash m={m} />
      <div className="wrap hero">
        <div>
          <h1>{name}</h1>
          <p className="lead">{s.tagline}</p>
          <a className="btn" href="#pustake">सर्व पुस्तके पहा</a><Link className="link" href="/about">लेखकाबद्दल</Link>
        </div>
        {feat && (
          <Link className="feat" href={`/book/${feat.id}`}>
            <Cover b={feat} name={name} />
            <p><b>{feat.title}</b>{feat.blurb}</p>
          </Link>
        )}
      </div>
      <div className="wrap" id="pustake">
        {CATS.map((c) => {
          const bs = books.filter((b) => b.category === c);
          if (!bs.length) return null;
          return (
            <section className="shelf" key={c}>
              <div className="shelf-head"><h2>{c}</h2><p>{CATINTRO[c]}</p></div>
              <div className="row">
                {bs.map((b) => (
                  <article className="book" key={b.id}>
                    <Link href={`/book/${b.id}`}><Cover b={b} name={name} /></Link>
                    <h3><Link href={`/book/${b.id}`}>{b.title}</Link></h3>
                    <p>{b.blurb}</p>
                  </article>
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </>
  );
}
