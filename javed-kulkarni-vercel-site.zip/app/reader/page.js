import Link from 'next/link';
import { q } from '@/lib/db';
import { requireUser } from '@/lib/auth';
import { getSettings } from '@/lib/settings';
import { stars } from '@/lib/util';
import Cover from '@/components/Cover';
import Confirm from '@/components/Confirm';
import Flash from '@/components/Flash';
export const metadata = { title: 'माझे पान' };
export default async function Reader({ searchParams }) {
  const { m } = await searchParams;
  const u = await requireUser();
  const s = await getSettings();
  const favs = await q('select b.* from favs f join books b on b.id=f.book_id where f.user_id=$1 order by b.sort', [u.id]);
  const revs = await q('select r.*,b.title from reviews r join books b on b.id=r.book_id where r.user_id=$1 order by r.created desc', [u.id]);
  return (
    <>
      <Flash m={m} />
      <div className="wrap page">
        <h1>नमस्कार, {u.name}</h1>
        <h2 style={{ fontSize: '1.6rem', margin: '2rem 0 1.2rem' }}>माझी आवडती पुस्तके</h2>
        {!favs.length && <p className="muted">अजून कोणतेही पुस्तक जोडलेले नाही. <Link href="/#pustake">पुस्तके पहा</Link>.</p>}
        <div className="row">
          {favs.map((b) => (
            <article className="book" key={b.id}>
              <Link href={`/book/${b.id}`}><Cover b={b} name={s.site_name} /></Link>
              <h3><Link href={`/book/${b.id}`}>{b.title}</Link></h3>
            </article>
          ))}
        </div>
        <h2 style={{ fontSize: '1.6rem', margin: '2rem 0 1rem' }}>माझे अभिप्राय</h2>
        {!revs.length && <p className="muted">तुम्ही अजून अभिप्राय दिलेला नाही.</p>}
        {revs.map((r) => (
          <div className="review" key={r.id}>
            <Link href={`/book/${r.book_id}`}><b>{r.title}</b></Link> <span className="stars">{stars(r.rating)}</span>
            <p style={{ whiteSpace: 'pre-line' }}>{r.body}</p>
            <form method="post" action="/api/myreview_del"><input type="hidden" name="id" value={r.id} /><Confirm msg="हा अभिप्राय काढायचा?" className="btn danger small">काढा</Confirm></form>
          </div>
        ))}
        <h2 style={{ fontSize: '1.6rem', margin: '2.5rem 0 1rem' }}>माझे खाते</h2>
        <form className="form" method="post" action="/api/profile" style={{ marginBottom: '2rem' }}>
          <label>नाव<input name="name" defaultValue={u.name} required /></label>
          <button className="btn" type="submit">नाव जतन करा</button>
        </form>
        <form className="form" method="post" action="/api/password">
          <label>जुना पासवर्ड<input type="password" name="oldpass" required /></label>
          <label>नवा पासवर्ड<input type="password" name="newpass" minLength={8} required /></label>
          <button className="btn" type="submit">पासवर्ड बदला</button>
        </form>
      </div>
    </>
  );
}
