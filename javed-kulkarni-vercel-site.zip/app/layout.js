import './globals.css';
import Link from 'next/link';
import { getUser } from '@/lib/auth';
import { getSettings } from '@/lib/settings';

export const dynamic = 'force-dynamic';

export async function generateMetadata() {
  const s = await getSettings();
  const n = s.site_name || 'जावेद कुलकर्णी';
  return { title: { default: `${n} – लेखक`, template: `%s – ${n}` }, description: s.tagline || 'लेखक वेबसाइट' };
}

export default async function RootLayout({ children }) {
  const u = await getUser();
  const s = await getSettings();
  const n = s.site_name || 'जावेद कुलकर्णी';
  const social = [['instagram', 'इन्स्टाग्राम'], ['facebook', 'फेसबुक'], ['goodreads', 'गुडरीड्स']].filter(([k]) => s[k]);
  return (
    <html lang="mr">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Tiro+Devanagari+Marathi&family=Mukta:wght@400;600&display=swap" />
      </head>
      <body>
        <header>
          <div className="wrap bar">
            <Link className="logo" href="/">{n}</Link>
            <nav>
              <Link href="/#pustake">पुस्तके</Link><Link href="/blog">लेखन</Link><Link href="/about">लेखक</Link><Link href="/contact">संपर्क</Link>
              {u ? (
                <>
                  {u.role === 'admin' && <Link href="/admin">ॲडमिन</Link>}
                  <Link href="/reader">माझे पान</Link>
                  <form method="post" action="/api/logout"><button className="linkbtn">बाहेर पडा</button></form>
                </>
              ) : (
                <><Link href="/login">लॉगिन</Link><Link className="pill" href="/register">नोंदणी</Link></>
              )}
            </nav>
          </div>
        </header>
        <main>{children}</main>
        <footer>
          <div className="wrap foot">
            <div>{social.map(([k, l]) => <a key={k} href={s[k]} target="_blank" rel="noopener noreferrer">{l}</a>)}</div>
            <div>© {new Date().getFullYear()} {n}. सर्व हक्क राखीव.</div>
          </div>
        </footer>
      </body>
    </html>
  );
}
