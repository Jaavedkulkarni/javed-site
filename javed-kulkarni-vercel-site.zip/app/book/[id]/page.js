import Link from 'next/link';
import { notFound } from 'next/navigation';
import { q, one } from '@/lib/db';
import { getUser } from '@/lib/auth';
import { getSettings } from '@/lib/settings';
import { stars, fmtDate } from '@/lib/util';
import Cover from '@/components/Cover';
import Flash from '@/components/Flash';

export async function generateMetadata({ params }) {
  const { id } = await params;
  const b = parseInt(id) ? await one('select title,blurb from books where id=$1', [parseInt(id)]).catch(() => null) : null;
  return b ? { title: b.title, description: b.blurb } : {};
}

export default async function BookPage({ params, searchParams }) {
  const { id } = await params;
  const { m } = await searchParams;
  const bid = parseInt(id);
  if (!bid) notFound();
  const b = await one('select * from books where id=$1', [bid]);
  if (!b) notFound();
  const [u, s] = [await getUser(), await getSettings()];
  const isfav = u ? !!(await one('select 1 as x from favs where user_id=$1 and book_id=$2', [u.id, bid])) : false;
  const avg = await one('select avg(rating) a,count(*) c from reviews where book_id=$1', [bid]);
  const revs = await q('select r.*,u.name from reviews r join users u on u.id=r.user_id where book_id=$1 order by created desc', [bid]);
  const count = Number(avg.c);
  return (
    <>
      <Flash m={m} />
      <div className="wrap page">
        <div className="two">
          <div><Cover b={b} name={s.site_name} /></div>
          <div className="body">
            <p className="muted"><Link href="/#pustake">{b.category}</Link></p>
            <h1>{b.title}</h1>
            {count > 0 && <p><span className="stars">{stars(Math.round(avg.a))}</span> <span className="muted">{Number(avg.a).toFixed(1)} ({count} अभिप्राय)</span></p>}
            <p style={{ whiteSpace: 'pre-line' }}>{b.description || b.blurb}</p>
            <p>
              {b.buy_url ? <a className="btn" href={b.buy_url} target="_blank" rel="noopener noreferrer">खरेदी करा</a> : <span className="muted">खरेदी लिंक लवकरच.</span>}{' '}
              {u ? (
                <form className="inline" method="post" action="/api/fav" style={{ marginLeft: '.8rem' }}>
                  <input type="hidden" name="book" value={b.id} />
                  <button className="btn ghost">{isfav ? '★ आवडत्या यादीत' : '☆ आवडत्या यादीत जोडा'}</button>
                </form>
              ) : <Link className="link" href="/login">आवडत्या यादीसाठी लॉगिन करा</Link>}
            </p>
            <h2 id="abhipray" style={{ marginTop: '3rem', fontSize: '1.6rem' }}>वाचकांचे अभिप्राय</h2>
            {u ? (
              <form className="form" method="post" action="/api/review">
                <input type="hidden" name="book" value={b.id} />
                <label>गुण<select name="rating">{[5, 4, 3, 2, 1].map((i) => <option key={i} value={i}>{stars(i)}</option>)}</select></label>
                <label>तुमचा अभिप्राय<textarea name="body" maxLength={1500} required /></label>
                <button className="btn" type="submit">अभिप्राय द्या</button>
              </form>
            ) : <p className="muted">अभिप्राय देण्यासाठी <Link href="/login">लॉगिन</Link> किंवा <Link href="/register">नोंदणी</Link> करा.</p>}
            {revs.map((r) => (
              <div className="review" key={r.id}>
                <span className="stars">{stars(r.rating)}</span> <b>{r.name}</b> <span className="muted">{fmtDate(r.created)}</span>
                <p style={{ whiteSpace: 'pre-line' }}>{r.body}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
