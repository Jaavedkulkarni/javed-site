import Link from 'next/link';
import Flash from '@/components/Flash';
export const metadata = { title: 'पासवर्ड विसरलात?' };
export default async function Forgot({ searchParams }) {
  const { m } = await searchParams;
  return (
    <>
      <Flash m={m} />
      <div className="wrap page narrow">
        <h1>पासवर्ड विसरलात?</h1>
        <p className="muted">तुमचा नोंदणीकृत ईमेल द्या. आम्ही पासवर्ड बदलण्याची लिंक पाठवू.</p>
        <form className="form" method="post" action="/api/forgot">
          <label>ईमेल<input type="email" name="email" required /></label>
          <button className="btn" type="submit">लिंक पाठवा</button>
        </form>
        <p className="muted"><Link href="/login">← लॉगिन</Link></p>
      </div>
    </>
  );
}
