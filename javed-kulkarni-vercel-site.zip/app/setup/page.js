import { one } from '@/lib/db';
import Flash from '@/components/Flash';
export const metadata = { title: 'सेटअप' };
export const dynamic = 'force-dynamic';
export default async function Setup({ searchParams }) {
  const { m } = await searchParams;
  let done = false, dbErr = false;
  try {
    const t = await one("select to_regclass('public.users') as t");
    done = !!(t.t && (await one("select 1 as x from users where role='admin' limit 1")));
  } catch { dbErr = true; }
  return (
    <>
      <Flash m={m} />
      <div className="wrap page narrow">
        <h1>वेबसाइट सेटअप</h1>
        {dbErr ? (
          <p className="flash">डेटाबेसला जोडता आले नाही. Vercel मध्ये <b>DATABASE_URL</b> बरोबर भरली आहे का ते तपासा आणि Redeploy करा.</p>
        ) : done ? (
          <p className="flash">वेबसाइट आधीच सेट झाली आहे. <a href="/login">लॉगिन करा</a>.</p>
        ) : !process.env.SETUP_KEY ? (
          <p className="flash">Vercel मध्ये <b>SETUP_KEY</b> नावाचा Environment Variable (तुमचा स्वतःचा गुप्त शब्द) जोडा, मग Redeploy करा.</p>
        ) : (
          <>
            <p className="muted">ॲडमिन खाते तयार करा. हे फक्त एकदाच करायचे आहे.</p>
            <form className="form" method="post" action="/api/setup">
              <label>सेटअप की (Vercel मध्ये भरलेला SETUP_KEY)<input type="password" name="key" required /></label>
              <label>तुमचे नाव<input name="name" required /></label>
              <label>ईमेल<input type="email" name="email" required /></label>
              <label>पासवर्ड (किमान ८ अक्षरे)<input type="password" name="password" minLength={8} required /></label>
              <button className="btn" type="submit">सेटअप करा</button>
            </form>
          </>
        )}
      </div>
    </>
  );
}
