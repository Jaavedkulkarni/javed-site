import { q } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { fmtDate } from '@/lib/util';
import AdminNav from '@/components/AdminNav';
import Confirm from '@/components/Confirm';
import Flash from '@/components/Flash';
export const metadata = { title: 'वाचक (ॲडमिन)' };
export default async function Readers({ searchParams }) {
  const { m } = await searchParams;
  await requireAdmin();
  const us = await q("select * from users where role='reader' order by created desc");
  return (
    <>
      <Flash m={m} />
      <div className="wrap adm">
        <AdminNav />
        <h1>नोंदणीकृत वाचक ({us.length})</h1>
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr><th>नाव</th><th>ईमेल</th><th>नोंदणी</th><th></th></tr></thead>
            <tbody>
              {us.map((u) => (
                <tr key={u.id}>
                  <td>{u.name}</td><td>{u.email}</td><td>{fmtDate(u.created)}</td>
                  <td><form method="post" action="/api/admin_reader_del"><input type="hidden" name="id" value={u.id} /><Confirm msg="हा वाचक काढायचा?" className="btn small danger">काढा</Confirm></form></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
