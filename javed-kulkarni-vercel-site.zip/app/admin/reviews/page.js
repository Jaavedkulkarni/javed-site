import { q } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { fmtDate, stars } from '@/lib/util';
import AdminNav from '@/components/AdminNav';
import Confirm from '@/components/Confirm';
import Flash from '@/components/Flash';
export const metadata = { title: 'अभिप्राय (ॲडमिन)' };
export default async function Reviews({ searchParams }) {
  const { m } = await searchParams;
  await requireAdmin();
  const rs = await q('select r.*,b.title,u.name from reviews r join books b on b.id=r.book_id join users u on u.id=r.user_id order by r.created desc');
  return (
    <>
      <Flash m={m} />
      <div className="wrap adm">
        <AdminNav />
        <h1>वाचकांचे अभिप्राय</h1>
        {!rs.length && <p className="muted">अजून कोणताही अभिप्राय नाही.</p>}
        {rs.map((r) => (
          <div className="review" key={r.id}>
            <b>{r.title}</b> <span className="stars">{stars(r.rating)}</span> · {r.name} <span className="muted">{fmtDate(r.created)}</span>
            <p style={{ whiteSpace: 'pre-line' }}>{r.body}</p>
            <form method="post" action="/api/admin_review_del"><input type="hidden" name="id" value={r.id} /><Confirm msg="अभिप्राय काढायचा?" className="btn small danger">काढा</Confirm></form>
          </div>
        ))}
      </div>
    </>
  );
}
