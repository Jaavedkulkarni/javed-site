import Link from 'next/link';
import { q, one } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { CATS } from '@/lib/util';
import AdminNav from '@/components/AdminNav';
import Confirm from '@/components/Confirm';
import Flash from '@/components/Flash';
export const metadata = { title: 'पुस्तके (ॲडमिन)' };
export default async function Books({ searchParams }) {
  const { m, edit } = await searchParams;
  await requireAdmin();
  const e = parseInt(edit) ? await one('select * from books where id=$1', [parseInt(edit)]) : null;
  const all = await q('select * from books order by category,sort,id');
  return (
    <>
      <Flash m={m} />
      <div className="wrap adm">
        <AdminNav />
        <h1>{e ? 'पुस्तक बदला' : 'नवीन पुस्तक'}</h1>
        <form className="form" method="post" action="/api/admin_book_save" encType="multipart/form-data" style={{ margin: '1.5rem 0 2rem' }} key={e?.id || 'new'}>
          <input type="hidden" name="id" value={e?.id || 0} />
          <label>नाव<input name="title" defaultValue={e?.title || ''} required /></label>
          <label>विभाग<select name="category" defaultValue={e?.category || CATS[0]}>{CATS.map((c) => <option key={c}>{c}</option>)}</select></label>
          <label>छोटा परिचय (एक-दोन ओळी)<input name="blurb" defaultValue={e?.blurb || ''} /></label>
          <label>सविस्तर माहिती<textarea name="description" defaultValue={e?.description || ''} /></label>
          <label>खरेदी लिंक (Amazon, Flipkart इ.)<input type="url" name="buy_url" defaultValue={e?.buy_url || ''} placeholder="https://" /></label>
          <label>कव्हर फोटो (JPG/PNG/WEBP, ३ MB पर्यंत)<input type="file" name="cover" accept="image/jpeg,image/png,image/webp" /></label>
          <label>क्रम (लहान आकडा आधी)<input type="number" name="sort" defaultValue={e?.sort || 0} /></label>
          <label className="check"><input type="checkbox" name="featured" value="1" defaultChecked={!!e?.featured} /> मुख्य पानावर ठळक दाखवा</label>
          <div><button className="btn" type="submit">जतन करा</button>{e && <Link className="link" href="/admin/books">रद्द करा</Link>}</div>
        </form>
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr><th>नाव</th><th>विभाग</th><th>कव्हर</th><th>लिंक</th><th></th></tr></thead>
            <tbody>
              {all.map((b) => (
                <tr key={b.id}>
                  <td>{b.title}{b.featured ? ' ★' : ''}</td><td>{b.category}</td><td>{b.cover ? 'आहे' : '—'}</td><td>{b.buy_url ? 'आहे' : '—'}</td>
                  <td>
                    <Link className="btn small ghost" href={`/admin/books?edit=${b.id}`}>बदला</Link>{' '}
                    <form method="post" action="/api/admin_book_del"><input type="hidden" name="id" value={b.id} /><Confirm msg="हे पुस्तक काढायचे?" className="btn small danger">काढा</Confirm></form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
