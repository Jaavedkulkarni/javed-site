import { q } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { fmtDate } from '@/lib/util';
import AdminNav from '@/components/AdminNav';
import Confirm from '@/components/Confirm';
import Flash from '@/components/Flash';
export const metadata = { title: 'संदेश (ॲडमिन)' };
export default async function Messages({ searchParams }) {
  const { m } = await searchParams;
  await requireAdmin();
  const ms = await q('select * from messages order by created desc');
  await q('update messages set is_read=1 where is_read=0');
  return (
    <>
      <Flash m={m} />
      <div className="wrap adm">
        <AdminNav />
        <h1>संदेश</h1>
        {!ms.length && <p className="muted">अजून कोणताही संदेश आलेला नाही.</p>}
        {ms.map((x) => (
          <div className="review" key={x.id}>
            <b>{x.name}</b> · <a href={`mailto:${x.email}`}>{x.email}</a> <span className="muted">{fmtDate(x.created)}</span>{!x.is_read && <b> (नवीन)</b>}
            <p style={{ whiteSpace: 'pre-line' }}>{x.body}</p>
            <form method="post" action="/api/admin_msg_del"><input type="hidden" name="id" value={x.id} /><Confirm msg="संदेश काढायचा?" className="btn small danger">काढा</Confirm></form>
          </div>
        ))}
      </div>
    </>
  );
}
