import { requireAdmin } from '@/lib/auth';
import { getSettings } from '@/lib/settings';
import AdminNav from '@/components/AdminNav';
import Flash from '@/components/Flash';
export const metadata = { title: 'सेटिंग्ज (ॲडमिन)' };
export default async function SettingsPage({ searchParams }) {
  const { m } = await searchParams;
  await requireAdmin();
  const s = await getSettings();
  return (
    <>
      <Flash m={m} />
      <div className="wrap adm">
        <AdminNav />
        <h1>सेटिंग्ज</h1>
        <form className="form" method="post" action="/api/admin_settings" encType="multipart/form-data" style={{ marginTop: '1.5rem', maxWidth: 700 }}>
          <label>लेखकाचे नाव<input name="site_name" defaultValue={s.site_name || ''} required /></label>
          <label>ओळ (मुख्य पानावर)<input name="tagline" defaultValue={s.tagline || ''} /></label>
          <label>लेखकाबद्दल<textarea name="bio" style={{ minHeight: 200 }} defaultValue={s.bio || ''} /></label>
          <label>तुमचा फोटो<input type="file" name="photo" accept="image/jpeg,image/png,image/webp" /></label>
          <label>तुमचा ईमेल (संपर्क पानावर दिसेल, आणि नवीन संदेशाची सूचना इथे येईल)<input type="email" name="email" defaultValue={s.email || ''} /></label>
          <label>वेबसाइटचा पत्ता (पासवर्ड रीसेट लिंकसाठी, उदा. https://javedkulkarni.com)<input type="url" name="site_url" defaultValue={s.site_url || ''} placeholder="https://" /></label>
          <label>Instagram लिंक<input type="url" name="instagram" defaultValue={s.instagram || ''} placeholder="https://" /></label>
          <label>Facebook लिंक<input type="url" name="facebook" defaultValue={s.facebook || ''} placeholder="https://" /></label>
          <label>Goodreads लिंक<input type="url" name="goodreads" defaultValue={s.goodreads || ''} placeholder="https://" /></label>
          <label>नवा ॲडमिन पासवर्ड (बदलायचा नसेल तर रिकामा ठेवा)<input type="password" name="newpass" minLength={8} /></label>
          <div><button className="btn" type="submit">जतन करा</button></div>
        </form>
      </div>
    </>
  );
}
