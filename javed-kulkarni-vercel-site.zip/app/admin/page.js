import Link from 'next/link';
import { one } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import AdminNav from '@/components/AdminNav';
import Flash from '@/components/Flash';
export const metadata = { title: 'ॲडमिन' };
export default async function Admin({ searchParams }) {
  const { m } = await searchParams;
  const u = await requireAdmin();
  const c = async (sql) => Number((await one(sql)).n);
  const [books, posts, readers, reviews, unread] = await Promise.all([
    c('select count(*) n from books'), c('select count(*) n from posts'), c("select count(*) n from users where role='reader'"),
    c('select count(*) n from reviews'), c('select count(*) n from messages where is_read=0'),
  ]);
  return (
    <>
      <Flash m={m} />
      <div className="wrap adm">
        <AdminNav />
        <h1>ॲडमिन डॅशबोर्ड</h1>
        <p className="muted">नमस्कार, {u.name}. येथून तुम्ही वेबसाइटचा सर्व मजकूर सांभाळू शकता.</p>
        <div className="cards" style={{ marginTop: '1.5rem' }}>
          <Link className="card" href="/admin/books"><b>{books}</b>पुस्तके</Link>
          <Link className="card" href="/admin/posts"><b>{posts}</b>लेखन</Link>
          <Link className="card" href="/admin/readers"><b>{readers}</b>नोंदणीकृत वाचक</Link>
          <Link className="card" href="/admin/reviews"><b>{reviews}</b>अभिप्राय</Link>
          <Link className="card" href="/admin/messages"><b>{unread}</b>न वाचलेले संदेश</Link>
        </div>
      </div>
    </>
  );
}
