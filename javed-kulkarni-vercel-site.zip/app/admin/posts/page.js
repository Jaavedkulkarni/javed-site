import Link from 'next/link';
import { q, one } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { fmtDate } from '@/lib/util';
import AdminNav from '@/components/AdminNav';
import Confirm from '@/components/Confirm';
import Flash from '@/components/Flash';
export const metadata = { title: 'लेखन (ॲडमिन)' };
export default async function Posts({ searchParams }) {
  const { m, edit } = await searchParams;
  await requireAdmin();
  const e = parseInt(edit) ? await one('select * from posts where id=$1', [parseInt(edit)]) : null;
  const all = await q('select * from posts order by created desc');
  return (
    <>
      <Flash m={m} />
      <div className="wrap adm">
        <AdminNav />
        <h1>{e ? 'लेख बदला' : 'नवीन लेख'}</h1>
        <form className="form" method="post" action="/api/admin_post_save" style={{ margin: '1.5rem 0 2rem', maxWidth: 760 }} key={e?.id || 'new'}>
          <input type="hidden" name="id" value={e?.id || 0} />
          <label>शीर्षक<input name="title" defaultValue={e?.title || ''} required /></label>
          <label>मजकूर<textarea name="body" style={{ minHeight: 260 }} defaultValue={e?.body || ''} /></label>
          <label className="check"><input type="checkbox" name="published" value="1" defaultChecked={e ? !!e.published : true} /> प्रसिद्ध करा</label>
          <div><button className="btn" type="submit">जतन करा</button>{e && <Link className="link" href="/admin/posts">रद्द करा</Link>}</div>
        </form>
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr><th>शीर्षक</th><th>तारीख</th><th>स्थिती</th><th></th></tr></thead>
            <tbody>
              {all.map((p) => (
                <tr key={p.id}>
                  <td>{p.title}</td><td>{fmtDate(p.created)}</td><td>{p.published ? 'प्रसिद्ध' : 'मसुदा'}</td>
                  <td>
                    <Link className="btn small ghost" href={`/admin/posts?edit=${p.id}`}>बदला</Link>{' '}
                    <form method="post" action="/api/admin_post_del"><input type="hidden" name="id" value={p.id} /><Confirm msg="हा लेख काढायचा?" className="btn small danger">काढा</Confirm></form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
