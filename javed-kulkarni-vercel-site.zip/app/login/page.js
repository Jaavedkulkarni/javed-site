import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getUser } from '@/lib/auth';
import Flash from '@/components/Flash';
export const metadata = { title: 'लॉगिन' };
export default async function Login({ searchParams }) {
  const { m } = await searchParams;
  if (await getUser()) redirect('/reader');
  return (
    <>
      <Flash m={m} />
      <div className="wrap page narrow">
        <h1>लॉगिन</h1>
        <form className="form" method="post" action="/api/login">
          <label>ईमेल<input type="email" name="email" required /></label>
          <label>पासवर्ड<input type="password" name="password" required /></label>
          <button className="btn" type="submit">लॉगिन</button>
        </form>
        <p className="muted">नवीन वाचक? <Link href="/register">नोंदणी करा</Link> · <Link href="/forgot">पासवर्ड विसरलात?</Link></p>
      </div>
    </>
  );
}
