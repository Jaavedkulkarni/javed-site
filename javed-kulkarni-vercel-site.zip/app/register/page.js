import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getUser } from '@/lib/auth';
import Flash from '@/components/Flash';
export const metadata = { title: 'नोंदणी' };
export default async function Register({ searchParams }) {
  const { m } = await searchParams;
  if (await getUser()) redirect('/reader');
  return (
    <>
      <Flash m={m} />
      <div className="wrap page narrow">
        <h1>वाचक नोंदणी</h1>
        <p className="muted">नोंदणी करून आवडती पुस्तके जतन करा आणि अभिप्राय द्या.</p>
        <form className="form" method="post" action="/api/register">
          <label>नाव<input name="name" required /></label>
          <label>ईमेल<input type="email" name="email" required /></label>
          <label>पासवर्ड (किमान ८ अक्षरे)<input type="password" name="password" minLength={8} required /></label>
          <button className="btn" type="submit">नोंदणी करा</button>
        </form>
        <p className="muted">आधीच खाते आहे? <Link href="/login">लॉगिन करा</Link></p>
      </div>
    </>
  );
}
