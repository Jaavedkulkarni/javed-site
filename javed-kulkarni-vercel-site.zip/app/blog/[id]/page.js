import Link from 'next/link';
import { notFound } from 'next/navigation';
import { one } from '@/lib/db';
import { fmtDate } from '@/lib/util';
export const dynamic = 'force-dynamic';
export default async function Post({ params }) {
  const { id } = await params;
  const p = parseInt(id) ? await one('select * from posts where id=$1 and published=1', [parseInt(id)]) : null;
  if (!p) notFound();
  return (
    <div className="wrap page body">
      <p className="muted"><Link href="/blog">← लेखन</Link></p>
      <h1>{p.title}</h1>
      <p className="muted">{fmtDate(p.created)}</p>
      <p style={{ whiteSpace: 'pre-line' }}>{p.body}</p>
    </div>
  );
}
