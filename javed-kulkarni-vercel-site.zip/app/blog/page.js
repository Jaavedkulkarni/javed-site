import Link from 'next/link';
import { q } from '@/lib/db';
import { fmtDate } from '@/lib/util';
export const dynamic = 'force-dynamic';
export const metadata = { title: 'लेखन' };
export default async function Blog() {
  const ps = await q('select * from posts where published=1 order by created desc');
  return (
    <div className="wrap page">
      <h1>लेखन</h1>
      {!ps.length && <p className="muted">लवकरच नवीन लेखन येथे येईल.</p>}
      {ps.map((p) => (
        <article className="post" key={p.id}>
          <h2><Link href={`/blog/${p.id}`}>{p.title}</Link></h2>
          <time>{fmtDate(p.created)}</time>
          <p>{(p.body || '').slice(0, 200)}…</p>
        </article>
      ))}
    </div>
  );
}
