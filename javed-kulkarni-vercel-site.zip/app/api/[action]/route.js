import { H } from '@/lib/handlers';
import { getUser } from '@/lib/auth';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const go = (loc) => new Response(null, { status: 303, headers: { Location: loc } });

export async function POST(req, { params }) {
  const { action } = await params;
  const fn = Object.hasOwn(H, action) ? H[action] : null;
  if (!fn) return new Response('Not found', { status: 404 });

  // CSRF: same-origin requests only
  const host = req.headers.get('x-forwarded-host') || req.headers.get('host');
  const origin = req.headers.get('origin');
  if (origin) {
    let ok = false;
    try { ok = new URL(origin).host === host; } catch {}
    if (!ok) return new Response('Forbidden', { status: 403 });
  }
  if (req.headers.get('sec-fetch-site') === 'cross-site') return new Response('Forbidden', { status: 403 });

  const user = await getUser();
  if (action.startsWith('admin_') && user?.role !== 'admin') return go('/login');

  let fd;
  try { fd = await req.formData(); } catch { fd = new FormData(); }
  try {
    return await fn(req, fd, user);
  } catch (e) {
    console.error(action, e);
    return go('/?m=' + encodeURIComponent('काहीतरी चूक झाली. पुन्हा प्रयत्न करा.'));
  }
}
