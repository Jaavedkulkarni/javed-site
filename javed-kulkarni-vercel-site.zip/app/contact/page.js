import Flash from '@/components/Flash';
import { getSettings } from '@/lib/settings';
export const metadata = { title: 'संपर्क' };
export default async function Contact({ searchParams }) {
  const { m } = await searchParams;
  const s = await getSettings();
  return (
    <>
      <Flash m={m} />
      <div className="wrap page">
        <h1>संपर्क</h1>
        {s.email && <p className="muted">ईमेल: {s.email}</p>}
        <form className="form" method="post" action="/api/contact">
          <input className="hp" name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" />
          <label>नाव<input name="name" required /></label>
          <label>ईमेल<input type="email" name="email" required /></label>
          <label>संदेश<textarea name="body" required /></label>
          <button className="btn" type="submit">पाठवा</button>
        </form>
      </div>
    </>
  );
}
