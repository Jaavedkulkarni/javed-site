import Link from 'next/link';
import { getSettings } from '@/lib/settings';
export const dynamic = 'force-dynamic';
export const metadata = { title: 'लेखक' };
export default async function About() {
  const s = await getSettings();
  return (
    <div className="wrap page">
      <div className="two">
        <div>{s.photo ? <img className="cimg" style={{ aspectRatio: '3/4' }} src={s.photo} alt={s.site_name} /> : <div className="card" style={{ aspectRatio: '3/4', display: 'grid', placeItems: 'center' }}>फोटो</div>}</div>
        <div className="body">
          <h1>{s.site_name}</h1>
          <p style={{ whiteSpace: 'pre-line' }}>{s.bio}</p>
          <p><Link className="btn" href="/contact">संपर्क करा</Link></p>
        </div>
      </div>
    </div>
  );
}
